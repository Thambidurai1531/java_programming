import java.util.*;
class Node{
   int data;
   Node prev;
   Node next;
   Node(int val){
      this.data = val;
      this.prev = null;
      this.next = null;
   }
}
class Linkedlist{
   Node head = null;

   void insert(int val){
      Node newNode = new Node(val);
      if(head == null){
         head = newNode;
      } else {
         Node temp = head;
         while(temp.next != null){
            temp = temp.next;
         }
         temp.next = newNode;
         newNode.prev = temp;
      }
   }

   boolean isPalindrome(){
      if(head==null||head.next==null) return true;
      Node left=head;
      Node right=head;
      while(right.next!=null){
         right=right.next;
      }
      while(left!=right&&left.prev!=right){
         if(left.data!=right.data){
            return false;
         }
         left=left.next;
         right=right.prev;
      }
      return true;
   }
}

public class Main{
   public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      Linkedlist ll = new Linkedlist();

      int n = sc.nextInt();
      for(int i = 0; i < n; i++){
         ll.insert(sc.nextInt());
      }

      if(ll.isPalindrome())
         System.out.print("Palindrome");
      else
         System.out.print("Not Palindrome");
   }
}
