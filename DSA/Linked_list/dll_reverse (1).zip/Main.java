import java.util.*;
class Node{
   int data;
   Node prev;
   Node next;
   Node(int val){
      this.data = val;
      this.prev = null;
      this.next = null;
   }
}

class Linkedlist{
   Node head = null;

   void insert(int val){
      Node newNode = new Node(val);
      if(head == null){
         head = newNode;
      } else {
         Node temp = head;
         while(temp.next != null){
            temp = temp.next;
         }
         temp.next = newNode;
         newNode.prev = temp;
      }
   }

   void reverse(){
      Node curr = head;
      Node temp = null;
      while(curr != null){
         temp = curr.prev;
         curr.prev = curr.next;
         curr.next = temp;
         curr = curr.prev;
      }
      if(temp != null){
         head = temp.prev;
      }
   }

   void display(){
      Node temp = head;
      while(temp != null){
         System.out.print(temp.data + " ");
         temp = temp.next;
      }
   }
}

public class Main{
   public static void main(String[] args){
      Scanner sc = new Scanner(System.in);
      Linkedlist ll = new Linkedlist();
      int n = sc.nextInt();
      for(int i = 0; i < n; i++){
         ll.insert(sc.nextInt());
      }
      ll.reverse();
      ll.display();
   }
}
