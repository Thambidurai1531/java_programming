import java.util.*;
class Node{
    int data;
    Node prev;
    Node next;
    Node(int val){
        this.data=val;
        this.prev=null;
        this.next=null;
    }
}
class Linkedlist{
    Node head=null;
    void insert(int val){
        Node newnode=new Node(val);
        if(head==null){
            head=newnode;
            newnode=head;
        }else{
            Node temp=head;
            while(temp.next!=null){
                temp=temp.next;
            }
            temp.next=newnode;
            newnode.prev=temp;
        }
    }
    void rotation(int k){
        if(head==null||head.next==null||k==0){
            return;
        }
        Node temp=head;
        int count=1;
        while(temp.next!=null){
            count++;
            temp=temp.next;
        }
        Node tail=temp;
        k=k%count;
        if(count==0){
            return;
        }
        tail.next=head;
        head.prev=tail;
        
        Node newtail=head;
        for(int i=1;i<count-k;i++){
            newtail=newtail.next;
        }
        Node newhead=newtail.next;
        
        newtail.next=null;
        newhead.prev=null;
        
        head=newhead;
    }
    void key(int k){
    int count = 1;
    Node temp = head;
    while(temp.next != null){
        temp = temp.next;
        count++;
    }
    temp.next = head;
    for(int i = 0; i < count-k; i++){
        temp = temp.next;
    }
    head = temp.next;
    temp.next = null;
}
    void display(){
        Node temp=head;
        while(temp!=null){
            System.out.print(temp.data+" ");
            temp=temp.next;
        }
    }
}
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        Linkedlist ll=new Linkedlist();
        for(int i=0;i<n;i++){
            int v=sc.nextInt();
            ll.insert(v);
        }
        int k=sc.nextInt();
        ll.key(k);
        ll.display();
    }
}