import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
   }
}
public class Main{
   public static void main(String[]args){
      Scanner sc=new Scanner(System.in);
      Node head=null;
      Node tail=null;
      int n=sc.nextInt();
      for(int i=0;i<n;i++){
         int v=sc.nextInt();
         Node node=new Node(v);
         if(head==null){
            head=node;
            tail=node;
         }else{
            tail.next=node;
            tail=node;
         }
      }
      int k=sc.nextInt();
      Node temp=head;
      for(int i=0;i<k-1;i++){
         temp=temp.next;
      }
      System.out.print(temp.data);
   }
}