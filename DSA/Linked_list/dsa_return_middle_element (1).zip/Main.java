import java.util.*;
class Node{
    int data;
    Node next;
    Node(int data){
        this.data=data;
        this.next=null;
    }
}
public class Main{
    public static void main(String[]args){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        Node head=null;
        Node tail=null;
        for(int i=0;i<n;i++){
            int v=sc.nextInt();
            Node node=new Node(v);
            if(head==null){
                head=node;
                tail=node;
            }else{
                tail.next=node;
                tail=node;
            }
        }
        int count =0;
        Node temp=head;
        while(temp!=null){
            count++;
            temp=temp.next;
        }
        int mid=(count+1)/2;
        temp=head;
        for(int i=1;i<mid;i++){
            temp=temp.next;
        }
        System.out.print(temp.data);
    }
}