import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
   }
}
public class Main
{
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   int n=sc.nextInt();
	   Node head=null;
	   for(int i=0;i<n;i++){
	      int v=sc.nextInt();
	      Node node=new Node(v);
	      node.next=head;
	      head=node;
	   }
	   if(head==null){
	      
	   }else if(head.next==null){
	      head=null;
	   }else{
	      Node temp=head;
	      while(temp.next.next!=null){
	         temp=temp.next;
	      }
	      temp.next=null;
	   }
	   Node temp=head;
	   while(temp!=null){
	      System.out.print(temp.data+" ");
	      temp=temp.next;
	   }
	}
}