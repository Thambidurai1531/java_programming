import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
   }
}
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Node head=null;
		for(int i=0;i<n;i++){
		   int v=sc.nextInt();
		   Node node=new Node(v);
		   node.next=head;
		   head=node;
		}
		int newval=sc.nextInt();
		Node NewNode=new Node(newval);
		NewNode.next=head;
		head=NewNode;
		while(head!=null){
		   System.out.print(head.data+" ");
		   head=head.next;
		}
	}
}