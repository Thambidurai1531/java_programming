import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
   }
}

public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Node head=null;
		Node tail=null;
		for(int i=0;i<n;i++){
		   int v=sc.nextInt();
		   Node node=new Node(v);
		   node.next=head;
		   head=node;
		}
		int newval=sc.nextInt();
       Node newNode=new Node(newval);
       
// 		newNode.next=head;
// 		head=newNode;

        if(head==null){
           head=newNode;
        }else{
           Node temp=head;
           while(temp.next!=null){
              temp=temp.next;
           }
           temp.next=newNode;
        }
        Node temp=head;
		while(temp!=null){
		   System.out.print(temp.data+" ");
		   temp=temp.next;
		}
	}
}