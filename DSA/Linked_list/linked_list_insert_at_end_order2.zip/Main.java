import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
   }
}

public class Main
{
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   int n=sc.nextInt();
	   Node head=null;
	   Node tail=null;
	   for(int i=0;i<n;i++){
	      int v=sc.nextInt();
	      Node node=new Node(v);
	      if(head==null){
	         head=node;
	         tail=node;
	      }else{
	         tail.next=node;
	         tail=node;
	      }
	     // node.next=head;
	     // head=node;
	   }
	   int newVal=sc.nextInt();
	   Node newNode =new Node(newVal);
	   if(head==null){
	      newNode=head;
	   }else {
	      Node temp=head;
	      while(temp.next!=null){
	         temp=temp.next;
	      }
	      temp.next=newNode;
	   }
	  // newNode.next=head;
	  // head=newNode;
	  Node temp=head;
	   while(temp!=null){
	      System.out.print(temp.data+" ");
	      temp=temp.next;
	   }
	}
}