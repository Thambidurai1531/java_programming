import java.util.*;
class Node{
   int data;
   Node next;
   Node(int data){
      this.data=data;
      this.next=null;
}
}
public class Main
{
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   Node head=null;
	   Node tail=null;
	   int n=sc.nextInt();
	   for(int i=0;i<n;i++){
	      int v=sc.nextInt();
	      Node node=new Node(v);
	      if(head==null){
	         head=node;
	         tail=node;
	      }else{
	         tail.next=node;
	         tail=node;
	      }
	   }
	   int newval=sc.nextInt();
	   Node newNode=new Node(newval);
	   int count=0;
	   Node temp=head;
	   while(temp!=null){
	      count++;
	      temp=temp.next;
	   }
	  int  mid=(count+1)/2;
	  temp=head;
	  for(int i=1;i<mid;i++){
	     temp=temp.next;
	  }
	  newNode.next=temp.next;
	  temp.next=newNode;
	  // newNode.next=head;
	  // head=newNode;
	  // if(head==null){
	  //    newNode=head;
	  // }else{
	  //    Node temp=head;
	  //    while(temp.next!=null){
	  //       temp=temp.next;
	  //    }
	  //    temp.next=newNode;
	  // }
	   temp=head;
	   while(temp!=null){
	      System.out.print(temp.data+" ");
	      temp=temp.next;
	   }
	}
}