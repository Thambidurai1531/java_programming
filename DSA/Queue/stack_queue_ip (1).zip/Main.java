import java.util.*;
public class Main{
   public static void main(String[]args){
      Scanner sc=new Scanner(System.in);
      Stack<Integer>s=new Stack<>();
      Queue<Integer> q=new LinkedList<>();
      int c=sc.nextInt();
      if(c==1){
      int n=sc.nextInt();
      for(int i=0;i<n;i++){
         s.push(sc.nextInt());
      }
      while(!s.isEmpty()){
         System.out.print(s.pop()+" ");
      }
      }else if (c==2){
         
         int k=sc.nextInt();
         for(int j=0;j<k;j++){
            q.add(sc.nextInt());
         }
         while(!q.isEmpty()){
            System.out.print(q.poll()+" ");
         }
      }
   }
}